﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderManagement.Refactor.Code.Services;

namespace TestClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // All Order
            IOrderManager manager = new OrderManager(new OrderFilter());
            manager.WriteOrder();

            // Large Order
            IOrderManager manager1 = new OrderManager(new LargeOrderFilter());
            manager.WriteOrder();

            // Small Order
            IOrderManager manager2 = new OrderManager(new SmallOrderFilter());
            manager.WriteOrder();
        }
    }
}
