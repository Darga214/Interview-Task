﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Refactor.Code.Dto
{
    public class Order
    {
        public double Price
        {
            get;
            set;
        }

        public int Size
        {
            get;
            set;
        }

        public string Symbol
        {
            get;
            set;
        }
    }
}
