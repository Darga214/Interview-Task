﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderManagement.Refactor.Code.Dto;

namespace OrderManagement.Refactor.Code.Services
{
    public class SmallOrderFilter : IOrderFilter
    {
        private const int fileSize = 10;
        public void WriteOutFiltrdAndPriceSortedOrders(IOrderWriter orderWriter, IOrderStore orderStore, IOrderFilter orderFilter)
        {
            var filteredOrders = orderStore.GetOrders().Where(o => o.Size < fileSize).OrderBy(x => x.Price).ToList();
            orderWriter.WriteOrders(filteredOrders);
        }
    }
}
