﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderManagement.Refactor.Code.Dto;

namespace OrderManagement.Refactor.Code.Services
{
    public interface IOrderFilter
    {
        void WriteOutFiltrdAndPriceSortedOrders(IOrderWriter orderWriter, IOrderStore orderStore, IOrderFilter orderFilter);
    }
}
