﻿using OrderManagement.Refactor.Code.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Refactor.Code.Services
{
    internal class OrderWriter : IOrderWriter
    {
        public void WriteOrders(IEnumerable<Order> orders)
        {
            throw new NotImplementedException();
        }
    }
}
