﻿using OrderManagement.Refactor.Code.Dto;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Refactor.Code.Services
{
    public class OrderFilter : IOrderFilter
    {
        public void WriteOutFiltrdAndPriceSortedOrders(IOrderWriter orderWriter, IOrderStore orderStore, IOrderFilter orderFilter)
        {
            throw new NotImplementedException();
        }
    }
}
