﻿using OrderManagement.Refactor.Code.Dto;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderManagement.Refactor.Code.Services
{
    public class OrderManager : IOrderManager
    {
        private readonly IOrderWriter _orderWriter;
        private readonly IOrderStore _orderStore;
        private readonly IOrderFilter _orderFilter;
        public OrderManager(IOrderFilter orderFilter)
        {
            _orderWriter = new OrderWriter();
            _orderStore = new OrderStore();
            _orderFilter = orderFilter;
        }
        public void WriteOrder()
        {
            _orderFilter.WriteOutFiltrdAndPriceSortedOrders(_orderWriter, _orderStore, _orderFilter);
        }
    }
}
