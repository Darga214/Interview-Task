What you have to do -

1. OrderManagement.csproj - contains several issues related to coding & design. Perform a code review on this project and refactor the code so that these
issues are address.

